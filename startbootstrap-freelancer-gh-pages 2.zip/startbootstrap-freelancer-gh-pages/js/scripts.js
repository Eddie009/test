/*!
* Start Bootstrap - Freelancer v7.0.5 (https://startbootstrap.com/theme/freelancer)
* Copyright 2013-2021 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-freelancer/blob/master/LICENSE)
*/
//
// Scripts
// 

(function(){var b=document.getElementsByClassName("jetBubble"),h=document.querySelector(".rocketManSVG");document.querySelector(".shakeGroup");var e=document.querySelector(".star"),a=document.querySelector(".satellite"),c=document.querySelector(".astronaut"),k=document.querySelector(".starContainer");document.querySelector("#badgeLink");TweenMax.to(c,.05,{y:"+=4",repeat:-1,yoyo:!0});var d=new TimelineMax({repeat:-1});c=new TimelineMax({repeat:-1,paused:!1});d.timeScale(6).seek(100);(new TimelineMax({repeat:-1})).to(a,
46,{rotation:360,transformOrigin:"50% 50%",ease:Linear.easeNone});TweenMax.staggerTo(".pulse",.8,{alpha:0,repeat:-1,ease:Power2.easeInOut,yoyo:!1},.1);TweenMax.staggerTo(".satellitePulse",.8,{alpha:0,repeat:-1,ease:Power2.easeInOut,yoyo:!1},.1);MorphSVGPlugin.convertToPath("#bubbble");TweenMax.set(b,{attr:{r:"-=5"}});for(a=0;a<b.length;a++){var f=b[a],g=new TimelineMax({repeat:-1});g.to(f,1,{attr:{r:"+=15"},ease:Linear.easeNone}).to(f,1,{attr:{r:"-=15"},ease:Linear.easeNone});d.add(g,a/4)}for(a=0;7>
a;a++)b=document.querySelector("#speedLine"+a),d=new TimelineMax({repeat:-1,repeatDelay:Math.random()}),d.set(b,{drawSVG:!1}).to(b,.05,{drawSVG:"0% 30%",ease:Linear.easeNone}).to(b,.2,{drawSVG:"70% 100%",ease:Linear.easeNone}).to(b,.05,{drawSVG:"100% 100%",ease:Linear.easeNone}).set(b,{drawSVG:"-1% -1%"}),c.add(d,a/23);for(a=0;7>a;a++)c=e.cloneNode(!0),k.appendChild(c),b=(a+1)/2,TweenMax.fromTo(c,b,{x:600*Math.random(),y:-30,scale:3-b},{y:100*Math.random()+600,repeat:-1,repeatDelay:1,ease:Linear.easeNone});
h.removeChild(e)})();

window.addEventListener('DOMContentLoaded', event => {

    // Navbar shrink function
    var navbarShrink = function () {
        const navbarCollapsible = document.body.querySelector('#mainNav');
        if (!navbarCollapsible) {
            return;
        }
        if (window.scrollY === 0) {
            navbarCollapsible.classList.remove('navbar-shrink')
        } else {
            navbarCollapsible.classList.add('navbar-shrink')
        }

    };

    // Shrink the navbar 
    navbarShrink();

    // Shrink the navbar when page is scrolled
    document.addEventListener('scroll', navbarShrink);

    // Activate Bootstrap scrollspy on the main nav element
    const mainNav = document.body.querySelector('#mainNav');
    if (mainNav) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#mainNav',
            offset: 72,
        });
    };

    // Collapse responsive navbar when toggler is visible
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

});
